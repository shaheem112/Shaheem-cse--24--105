// ex11_7.cpp
class base {
public:
    virtual void show() = 0;
};

