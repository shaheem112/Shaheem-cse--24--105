class book : public publication, public sales {
};
class tape : public publication, public sales {
};

