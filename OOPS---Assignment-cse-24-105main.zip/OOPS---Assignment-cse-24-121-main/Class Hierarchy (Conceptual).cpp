// Vehicle (base)
// |
// +-- Car
// |
// +-- Truck

