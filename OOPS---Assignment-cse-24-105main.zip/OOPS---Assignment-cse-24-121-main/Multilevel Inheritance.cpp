class A {
protected:
    int x;
};

class B : public A {
};

class C : public B {
};

